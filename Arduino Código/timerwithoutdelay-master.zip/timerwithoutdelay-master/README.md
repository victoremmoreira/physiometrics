# timerwithoutdelay
Temporizador para o Arduino sem o comando Delay - Timer for Arduino without Delay command
